TW.Runtime.Widgets.DiffViewer = function () {
	var valueElem;
	var widgetElement;
	var thisWidget = this;
	
	var args={
        source: null,
        mode  : "beautify",
        lang  : "auto"
    };
	  this.runtimeProperties = function () {
	        return {
                'supportsAutoResize': true
	        };
	    };
		
	this.renderHtml = function () {
		args.source=this.GetText();
		var html='<div class="widget-content widget-DiffViewer"></div>';
		return html;
	};
	
	this.GetText = function()
	{
		return this.getProperty("DiffText");
	}
	
	this.afterRender = function () {
	};

	
		
		
	this.updateProperty = function (updatePropertyInfo) {
		
		
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'DiffText') {
			var str_Diff = updatePropertyInfo.SinglePropertyValue;
			var html=Diff2Html.getPrettyHtmlFromDiff(str_Diff,{inputFormat:'diff',outputFormat: 'line-by-line'});
			this.jqElement.html(html);
			this.setProperty('Text', updatePropertyInfo.SinglePropertyValue);
		}
	};
};